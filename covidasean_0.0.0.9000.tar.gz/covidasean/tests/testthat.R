library(testthat)
library(covidasean)

test_check("covidasean")
